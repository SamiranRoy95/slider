// setInterval(

//     function(){
//         document.write("hello");
//     }
// ,1000);

// function slider(){
//     document.write("hello");
// }

// setInterval(slider,1000);

// document.querySelector("#changeSlide").addEventListener("click",function(){
//     if(document.getElementsByClassName("slider_items")[0].classList.contains("active")){

//         document.getElementsByClassName("slider_items")[1].classList.add("active");
//         document.getElementsByClassName("slider_items")[0].classList.remove("active")
//     }else if(document.getElementsByClassName("slider_items")[1].classList.contains("active")) {
    
//         document.getElementsByClassName("slider_items")[2].classList.add("active");
//         document.getElementsByClassName("slider_items")[1].classList.remove("active")
//     }else if(document.getElementsByClassName("slider_items")[2].classList.contains("active")){
    
//         document.getElementsByClassName("slider_items")[3].classList.add("active");
//         document.getElementsByClassName("slider_items")[2].classList.remove("active")
//     } else if (document.getElementsByClassName("slider_items")[3].classList.contains("active")){
//         document.getElementsByClassName("slider_items")[0].classList.add("active");
//         document.getElementsByClassName("slider_items")[3].classList.remove("active")
//     };  

// })

setInterval(function(){
    if(document.getElementsByClassName("slider_items")[0].classList.contains("active")){

        document.getElementsByClassName("slider_items")[1].classList.add("active");
        document.getElementsByClassName("slider_items")[0].classList.remove("active")
    }else if(document.getElementsByClassName("slider_items")[1].classList.contains("active")) {
    
        document.getElementsByClassName("slider_items")[2].classList.add("active");
        document.getElementsByClassName("slider_items")[1].classList.remove("active")
    }else if(document.getElementsByClassName("slider_items")[2].classList.contains("active")){
    
        document.getElementsByClassName("slider_items")[3].classList.add("active");
        document.getElementsByClassName("slider_items")[2].classList.remove("active")
    } else if (document.getElementsByClassName("slider_items")[3].classList.contains("active")){
        document.getElementsByClassName("slider_items")[0].classList.add("active");
        document.getElementsByClassName("slider_items")[3].classList.remove("active")
    };  

},1000)



